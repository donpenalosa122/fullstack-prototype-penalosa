// ============================================
// GLOBAL STATE & CONSTANTS
// ============================================

const STORAGE_KEY = 'ipt_demo_v1';
let currentUser = null;

// Database structure
window.db = {
    accounts: [],
    departments: [],
    employees: [],
    requests: []
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    handleRouting();
    
    // Listen for hash changes
    window.addEventListener('hashchange', handleRouting);
    
    // Set default hash if empty
    if (!window.location.hash) {
        window.location.hash = '#/';
    }
});

// ============================================
// STORAGE MANAGEMENT
// ============================================

function loadFromStorage() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            window.db = JSON.parse(saved);
        } else {
            // Seed initial data
            seedDatabase();
        }
    } catch (error) {
        console.error('Error loading from storage:', error);
        seedDatabase();
    }
    
    // Check if user is logged in
    const authToken = localStorage.getItem('auth_token');
    if (authToken) {
        const user = window.db.accounts.find(acc => acc.email === authToken);
        if (user && user.verified) {
            setAuthState(true, user);
        } else {
            localStorage.removeItem('auth_token');
        }
    }
}

function saveToStorage() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(window.db));
    } catch (error) {
        console.error('Error saving to storage:', error);
    }
}

function seedDatabase() {
    window.db = {
        accounts: [
            {
                id: generateId(),
                firstName: 'Admin',
                lastName: 'User',
                email: 'admin@example.com',
                password: 'Password123!',
                role: 'Admin',
                verified: true
            }
        ],
        departments: [
            {
                id: generateId(),
                name: 'Engineering',
                description: 'Software team'
            },
            {
                id: generateId(),
                name: 'HR',
                description: 'Human Resources'
            }
        ],
        employees: [],
        requests: []
    };
    saveToStorage();
}

function generateId() {
    return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// ============================================
// ROUTING
// ============================================

function navigateTo(hash) {
    window.location.hash = hash;
}

function handleRouting() {
    const hash = window.location.hash || '#/';
    const route = hash.substring(2); // Remove '#/'
    
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Protected routes
    const protectedRoutes = ['profile', 'requests'];
    const adminRoutes = ['employees', 'accounts', 'departments'];
    
    // Check authentication for protected routes
    if (protectedRoutes.includes(route) && !currentUser) {
        showToast('Please login to access this page', 'warning');
        navigateTo('#/login');
        return;
    }
    
    // Check admin access
    if (adminRoutes.includes(route) && (!currentUser || currentUser.role !== 'Admin')) {
        showToast('Admin access required', 'danger');
        navigateTo('#/');
        return;
    }
    
    // Show the appropriate page
    let pageId = route ? route + '-page' : 'home-page';
    const page = document.getElementById(pageId);
    
    if (page) {
        page.classList.add('active');
        
        // Render dynamic content
        switch(route) {
            case 'profile':
                renderProfile();
                break;
            case 'employees':
                renderEmployees();
                break;
            case 'departments':
                renderDepartments();
                break;
            case 'accounts':
                renderAccounts();
                break;
            case 'requests':
                renderRequests();
                break;
        }
    } else {
        document.getElementById('home-page').classList.add('active');
    }
}

// ============================================
// AUTHENTICATION
// ============================================

function handleRegister(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const email = formData.get('email');
    
    // Check if email already exists
    if (window.db.accounts.find(acc => acc.email === email)) {
        showToast('Email already registered', 'danger');
        return;
    }
    
    // Create new account
    const newAccount = {
        id: generateId(),
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
        email: email,
        password: formData.get('password'),
        role: 'User',
        verified: false
    };
    
    window.db.accounts.push(newAccount);
    saveToStorage();
    
    // Store email for verification
    localStorage.setItem('unverified_email', email);
    
    showToast('Registration successful! Please verify your email.', 'success');
    navigateTo('#/verify-email');
    
    // Update verify email display
    document.getElementById('verifyEmail').textContent = email;
}

function simulateVerification() {
    const email = localStorage.getItem('unverified_email');
    if (!email) {
        showToast('No pending verification', 'warning');
        return;
    }
    
    const account = window.db.accounts.find(acc => acc.email === email);
    if (account) {
        account.verified = true;
        saveToStorage();
        localStorage.removeItem('unverified_email');
        showToast('Email verified! You can now log in.', 'success');
        
        // Show success message on login page
        setTimeout(() => {
            document.getElementById('loginMessage').innerHTML = 
                '<div class="alert alert-success">✅ Email verified! You may now log in.</div>';
        }, 100);
        
        navigateTo('#/login');
    }
}

function handleLogin(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const email = formData.get('email');
    const password = formData.get('password');
    
    // Find account
    const account = window.db.accounts.find(acc => 
        acc.email === email && 
        acc.password === password && 
        acc.verified === true
    );
    
    if (account) {
        localStorage.setItem('auth_token', email);
        setAuthState(true, account);
        showToast('Login successful!', 'success');
        navigateTo('#/profile');
        form.reset();
    } else {
        showToast('Invalid credentials or unverified account', 'danger');
    }
}

function logout() {
    localStorage.removeItem('auth_token');
    setAuthState(false);
    showToast('Logged out successfully', 'info');
    navigateTo('#/');
}

function setAuthState(isAuth, user = null) {
    currentUser = user;
    const body = document.body;
    
    if (isAuth && user) {
        body.classList.remove('not-authenticated');
        body.classList.add('authenticated');
        
        if (user.role === 'Admin') {
            body.classList.add('is-admin');
        } else {
            body.classList.remove('is-admin');
        }
        
        // Update nav username
        document.getElementById('navUsername').textContent = user.firstName + ' ' + user.lastName;
    } else {
        body.classList.remove('authenticated', 'is-admin');
        body.classList.add('not-authenticated');
        currentUser = null;
    }
}

// ============================================
// PROFILE PAGE
// ============================================

function renderProfile() {
    if (!currentUser) return;
    
    const html = `
        <div class="row">
            <div class="col-md-6">
                <p><strong>${currentUser.firstName} ${currentUser.lastName}</strong></p>
                <p><strong>Email:</strong> ${currentUser.email}</p>
                <p><strong>Role:</strong> ${currentUser.role}</p>
                <button class="btn btn-primary mt-3" onclick="alert('Edit profile feature coming soon!')">Edit Profile</button>
            </div>
        </div>
    `;
    
    document.getElementById('profileContent').innerHTML = html;
}

// ============================================
// EMPLOYEES CRUD
// ============================================

function renderEmployees() {
    const tbody = document.getElementById('employeesTable');
    
    if (window.db.employees.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">No employees.</td></tr>';
        return;
    }
    
    const html = window.db.employees.map(emp => {
        const user = window.db.accounts.find(acc => acc.email === emp.userEmail);
        const dept = window.db.departments.find(d => d.id === emp.department);
        const userName = user ? `${user.firstName} ${user.lastName}` : emp.userEmail;
        const deptName = dept ? dept.name : 'N/A';
        
        return `
            <tr>
                <td>${emp.employeeId}</td>
                <td>${userName}</td>
                <td>${emp.position}</td>
                <td>${deptName}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editEmployee('${emp.id}')">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteEmployee('${emp.id}')">Delete</button>
                </td>
            </tr>
        `;
    }).join('');
    
    tbody.innerHTML = html;
    
    // Populate form dropdowns
    populateEmployeeFormDropdowns();
}

function populateEmployeeFormDropdowns() {
    // Populate users dropdown
    const userSelect = document.querySelector('#employeeForm select[name="userEmail"]');
    const userOptions = window.db.accounts.map(acc => 
        `<option value="${acc.email}">${acc.firstName} ${acc.lastName} (${acc.email})</option>`
    ).join('');
    userSelect.innerHTML = '<option value="">Select User</option>' + userOptions;
    
    // Populate departments dropdown
    const deptSelect = document.querySelector('#employeeForm select[name="department"]');
    const deptOptions = window.db.departments.map(dept => 
        `<option value="${dept.id}">${dept.name}</option>`
    ).join('');
    deptSelect.innerHTML = '<option value="">Select Department</option>' + deptOptions;
}

function showEmployeeForm(id = null) {
    document.getElementById('employeeFormContainer').style.display = 'block';
    const form = document.getElementById('employeeForm');
    
    if (id) {
        const employee = window.db.employees.find(e => e.id === id);
        if (employee) {
            form.elements['id'].value = employee.id;
            form.elements['employeeId'].value = employee.employeeId;
            form.elements['userEmail'].value = employee.userEmail;
            form.elements['position'].value = employee.position;
            form.elements['department'].value = employee.department;
            form.elements['hireDate'].value = employee.hireDate;
        }
    } else {
        form.reset();
    }
    
    populateEmployeeFormDropdowns();
}

function hideEmployeeForm() {
    document.getElementById('employeeFormContainer').style.display = 'none';
    document.getElementById('employeeForm').reset();
}

function handleEmployeeSave(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const employeeData = {
        employeeId: formData.get('employeeId'),
        userEmail: formData.get('userEmail'),
        position: formData.get('position'),
        department: formData.get('department'),
        hireDate: formData.get('hireDate')
    };
    
    const id = formData.get('id');
    
    if (id) {
        // Update existing
        const index = window.db.employees.findIndex(e => e.id === id);
        if (index !== -1) {
            window.db.employees[index] = { ...window.db.employees[index], ...employeeData };
            showToast('Employee updated successfully', 'success');
        }
    } else {
        // Create new
        employeeData.id = generateId();
        window.db.employees.push(employeeData);
        showToast('Employee added successfully', 'success');
    }
    
    saveToStorage();
    hideEmployeeForm();
    renderEmployees();
}

function editEmployee(id) {
    showEmployeeForm(id);
}

function deleteEmployee(id) {
    if (confirm('Are you sure you want to delete this employee?')) {
        window.db.employees = window.db.employees.filter(e => e.id !== id);
        saveToStorage();
        showToast('Employee deleted', 'info');
        renderEmployees();
    }
}

// ============================================
// DEPARTMENTS CRUD
// ============================================

function renderDepartments() {
    const tbody = document.getElementById('departmentsTable');
    
    if (window.db.departments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center">No departments.</td></tr>';
        return;
    }
    
    const html = window.db.departments.map(dept => `
        <tr>
            <td>${dept.name}</td>
            <td>${dept.description}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editDepartment('${dept.id}')">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteDepartment('${dept.id}')">Delete</button>
            </td>
        </tr>
    `).join('');
    
    tbody.innerHTML = html;
}

function showDepartmentForm(id = null) {
    document.getElementById('departmentFormContainer').style.display = 'block';
    const form = document.getElementById('departmentForm');
    
    if (id) {
        const dept = window.db.departments.find(d => d.id === id);
        if (dept) {
            form.elements['id'].value = dept.id;
            form.elements['name'].value = dept.name;
            form.elements['description'].value = dept.description;
        }
    } else {
        form.reset();
    }
}

function hideDepartmentForm() {
    document.getElementById('departmentFormContainer').style.display = 'none';
    document.getElementById('departmentForm').reset();
}

function handleDepartmentSave(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const deptData = {
        name: formData.get('name'),
        description: formData.get('description')
    };
    
    const id = formData.get('id');
    
    if (id) {
        const index = window.db.departments.findIndex(d => d.id === id);
        if (index !== -1) {
            window.db.departments[index] = { ...window.db.departments[index], ...deptData };
            showToast('Department updated successfully', 'success');
        }
    } else {
        deptData.id = generateId();
        window.db.departments.push(deptData);
        showToast('Department added successfully', 'success');
    }
    
    saveToStorage();
    hideDepartmentForm();
    renderDepartments();
}

function editDepartment(id) {
    showDepartmentForm(id);
}

function deleteDepartment(id) {
    if (confirm('Are you sure you want to delete this department?')) {
        window.db.departments = window.db.departments.filter(d => d.id !== id);
        saveToStorage();
        showToast('Department deleted', 'info');
        renderDepartments();
    }
}

// ============================================
// ACCOUNTS CRUD
// ============================================

function renderAccounts() {
    const tbody = document.getElementById('accountsTable');
    
    const html = window.db.accounts.map(acc => `
        <tr>
            <td>${acc.firstName} ${acc.lastName}</td>
            <td>${acc.email}</td>
            <td>${acc.role}</td>
            <td>${acc.verified ? '✅' : '—'}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editAccount('${acc.id}')">Edit</button>
                <button class="btn btn-sm btn-warning" onclick="resetPassword('${acc.id}')">Reset Password</button>
                <button class="btn btn-sm btn-danger" onclick="deleteAccount('${acc.id}')" ${currentUser && currentUser.email === acc.email ? 'disabled' : ''}>Delete</button>
            </td>
        </tr>
    `).join('');
    
    tbody.innerHTML = html;
}

function showAccountForm(id = null) {
    document.getElementById('accountFormContainer').style.display = 'block';
    const form = document.getElementById('accountForm');
    
    if (id) {
        const account = window.db.accounts.find(a => a.id === id);
        if (account) {
            form.elements['id'].value = account.id;
            form.elements['firstName'].value = account.firstName;
            form.elements['lastName'].value = account.lastName;
            form.elements['email'].value = account.email;
            form.elements['password'].value = account.password;
            form.elements['role'].value = account.role;
            form.elements['verified'].checked = account.verified;
        }
    } else {
        form.reset();
    }
}

function hideAccountForm() {
    document.getElementById('accountFormContainer').style.display = 'none';
    document.getElementById('accountForm').reset();
}

function handleAccountSave(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const accountData = {
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
        email: formData.get('email'),
        password: formData.get('password'),
        role: formData.get('role'),
        verified: formData.get('verified') === 'on'
    };
    
    const id = formData.get('id');
    
    if (id) {
        const index = window.db.accounts.findIndex(a => a.id === id);
        if (index !== -1) {
            window.db.accounts[index] = { ...window.db.accounts[index], ...accountData };
            showToast('Account updated successfully', 'success');
        }
    } else {
        // Check if email exists
        if (window.db.accounts.find(a => a.email === accountData.email)) {
            showToast('Email already exists', 'danger');
            return;
        }
        accountData.id = generateId();
        window.db.accounts.push(accountData);
        showToast('Account created successfully', 'success');
    }
    
    saveToStorage();
    hideAccountForm();
    renderAccounts();
}

function editAccount(id) {
    showAccountForm(id);
}

function resetPassword(id) {
    const newPassword = prompt('Enter new password (min 6 characters):');
    if (newPassword && newPassword.length >= 6) {
        const account = window.db.accounts.find(a => a.id === id);
        if (account) {
            account.password = newPassword;
            saveToStorage();
            showToast('Password reset successfully', 'success');
        }
    } else if (newPassword !== null) {
        showToast('Password must be at least 6 characters', 'warning');
    }
}

function deleteAccount(id) {
    // Prevent self-deletion
    if (currentUser && window.db.accounts.find(a => a.id === id && a.email === currentUser.email)) {
        showToast('Cannot delete your own account', 'warning');
        return;
    }
    
    if (confirm('Are you sure you want to delete this account?')) {
        window.db.accounts = window.db.accounts.filter(a => a.id !== id);
        saveToStorage();
        showToast('Account deleted', 'info');
        renderAccounts();
    }
}

// ============================================
// REQUESTS
// ============================================

function renderRequests() {
    if (!currentUser) return;
    
    const userRequests = window.db.requests.filter(req => req.employeeEmail === currentUser.email);
    const container = document.getElementById('requestsContainer');
    
    if (userRequests.length === 0) {
        container.innerHTML = `
            <div class="alert alert-info">
                You have no requests yet.
                <button class="btn btn-sm btn-primary ms-2" onclick="showRequestModal()">Create One</button>
            </div>
        `;
        return;
    }
    
    const html = userRequests.map(req => {
        const statusClass = req.status === 'Pending' ? 'warning' : 
                          req.status === 'Approved' ? 'success' : 'danger';
        const itemsList = req.items.map(item => `<li>${item.name} (Qty: ${item.qty})</li>`).join('');
        
        return `
            <div class="card request-card status-${req.status.toLowerCase()} mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 class="card-title">${req.type} Request</h5>
                            <p class="text-muted small">Submitted: ${new Date(req.date).toLocaleDateString()}</p>
                        </div>
                        <span class="badge bg-${statusClass}">${req.status}</span>
                    </div>
                    <div class="mt-2">
                        <strong>Items:</strong>
                        <ul class="mb-0 mt-1">
                            ${itemsList}
                        </ul>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = html;
}

function showRequestModal() {
    const modal = new bootstrap.Modal(document.getElementById('requestModal'));
    document.getElementById('requestForm').reset();
    
    // Reset items to one row
    document.getElementById('itemsContainer').innerHTML = `
        <div class="input-group mb-2 item-row">
            <input type="text" class="form-control" placeholder="Item name" name="itemName[]" required>
            <input type="number" class="form-control" placeholder="Qty" name="itemQty[]" min="1" value="1" style="max-width: 80px;" required>
            <button type="button" class="btn btn-outline-danger" onclick="removeItemRow(this)">×</button>
        </div>
    `;
    
    modal.show();
}

function addItemRow() {
    const container = document.getElementById('itemsContainer');
    const row = document.createElement('div');
    row.className = 'input-group mb-2 item-row';
    row.innerHTML = `
        <input type="text" class="form-control" placeholder="Item name" name="itemName[]" required>
        <input type="number" class="form-control" placeholder="Qty" name="itemQty[]" min="1" value="1" style="max-width: 80px;" required>
        <button type="button" class="btn btn-outline-danger" onclick="removeItemRow(this)">×</button>
    `;
    container.appendChild(row);
}

function removeItemRow(button) {
    const container = document.getElementById('itemsContainer');
    if (container.children.length > 1) {
        button.closest('.item-row').remove();
    } else {
        showToast('Must have at least one item', 'warning');
    }
}

function handleRequestSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const itemNames = formData.getAll('itemName[]');
    const itemQtys = formData.getAll('itemQty[]');
    
    const items = itemNames.map((name, index) => ({
        name: name,
        qty: parseInt(itemQtys[index])
    }));
    
    if (items.length === 0) {
        showToast('Must have at least one item', 'warning');
        return;
    }
    
    const request = {
        id: generateId(),
        type: formData.get('type'),
        items: items,
        status: 'Pending',
        date: new Date().toISOString(),
        employeeEmail: currentUser.email
    };
    
    window.db.requests.push(request);
    saveToStorage();
    
    showToast('Request submitted successfully', 'success');
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('requestModal'));
    modal.hide();
    
    renderRequests();
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    
    // Set color based on type
    toast.className = 'toast';
    if (type === 'success') {
        toast.classList.add('bg-success', 'text-white');
    } else if (type === 'danger') {
        toast.classList.add('bg-danger', 'text-white');
    } else if (type === 'warning') {
        toast.classList.add('bg-warning');
    } else {
        toast.classList.add('bg-info', 'text-white');
    }
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
}